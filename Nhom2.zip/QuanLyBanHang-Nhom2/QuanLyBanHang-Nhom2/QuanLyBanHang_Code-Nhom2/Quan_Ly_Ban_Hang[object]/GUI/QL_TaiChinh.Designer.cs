﻿namespace QL_BanHang
{
    partial class QL_TaiChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTienNam = new System.Windows.Forms.TextBox();
            this.txtTienThang = new System.Windows.Forms.TextBox();
            this.grbThang = new System.Windows.Forms.GroupBox();
            this.btnTinhThang = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtThang = new System.Windows.Forms.TextBox();
            this.txtTienNgay = new System.Windows.Forms.TextBox();
            this.grbNgay = new System.Windows.Forms.GroupBox();
            this.btnTinhNgay = new System.Windows.Forms.Button();
            this.lblLoiNhuan = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNgay = new System.Windows.Forms.TextBox();
            this.btnTinhNam = new System.Windows.Forms.Button();
            this.grbNam = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNam = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvLoiNhuan = new System.Windows.Forms.DataGridView();
            this.cmbHinhThuc = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grbThang.SuspendLayout();
            this.grbNgay.SuspendLayout();
            this.grbNam.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoiNhuan)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTienNam
            // 
            this.txtTienNam.Location = new System.Drawing.Point(360, 19);
            this.txtTienNam.Name = "txtTienNam";
            this.txtTienNam.Size = new System.Drawing.Size(100, 20);
            this.txtTienNam.TabIndex = 3;
            // 
            // txtTienThang
            // 
            this.txtTienThang.Location = new System.Drawing.Point(360, 21);
            this.txtTienThang.Name = "txtTienThang";
            this.txtTienThang.Size = new System.Drawing.Size(100, 20);
            this.txtTienThang.TabIndex = 3;
            // 
            // grbThang
            // 
            this.grbThang.Controls.Add(this.txtTienThang);
            this.grbThang.Controls.Add(this.btnTinhThang);
            this.grbThang.Controls.Add(this.label4);
            this.grbThang.Controls.Add(this.txtThang);
            this.grbThang.Location = new System.Drawing.Point(135, 131);
            this.grbThang.Name = "grbThang";
            this.grbThang.Size = new System.Drawing.Size(477, 59);
            this.grbThang.TabIndex = 9;
            this.grbThang.TabStop = false;
            this.grbThang.Text = "Theo Tháng";
            // 
            // btnTinhThang
            // 
            this.btnTinhThang.Location = new System.Drawing.Point(248, 19);
            this.btnTinhThang.Name = "btnTinhThang";
            this.btnTinhThang.Size = new System.Drawing.Size(75, 23);
            this.btnTinhThang.TabIndex = 2;
            this.btnTinhThang.Text = "Tính";
            this.btnTinhThang.UseVisualStyleBackColor = true;
            this.btnTinhThang.Click += new System.EventHandler(this.btnTinhThang_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Tháng";
            // 
            // txtThang
            // 
            this.txtThang.Location = new System.Drawing.Point(74, 21);
            this.txtThang.Name = "txtThang";
            this.txtThang.Size = new System.Drawing.Size(139, 20);
            this.txtThang.TabIndex = 1;
            // 
            // txtTienNgay
            // 
            this.txtTienNgay.Location = new System.Drawing.Point(360, 31);
            this.txtTienNgay.Name = "txtTienNgay";
            this.txtTienNgay.Size = new System.Drawing.Size(100, 20);
            this.txtTienNgay.TabIndex = 3;
            // 
            // grbNgay
            // 
            this.grbNgay.Controls.Add(this.txtTienNgay);
            this.grbNgay.Controls.Add(this.btnTinhNgay);
            this.grbNgay.Controls.Add(this.lblLoiNhuan);
            this.grbNgay.Controls.Add(this.label3);
            this.grbNgay.Controls.Add(this.txtNgay);
            this.grbNgay.Location = new System.Drawing.Point(135, 56);
            this.grbNgay.Name = "grbNgay";
            this.grbNgay.Size = new System.Drawing.Size(477, 69);
            this.grbNgay.TabIndex = 8;
            this.grbNgay.TabStop = false;
            this.grbNgay.Text = "Theo Ngày";
            // 
            // btnTinhNgay
            // 
            this.btnTinhNgay.Location = new System.Drawing.Point(248, 29);
            this.btnTinhNgay.Name = "btnTinhNgay";
            this.btnTinhNgay.Size = new System.Drawing.Size(75, 23);
            this.btnTinhNgay.TabIndex = 2;
            this.btnTinhNgay.Text = "Tính";
            this.btnTinhNgay.UseVisualStyleBackColor = true;
            this.btnTinhNgay.Click += new System.EventHandler(this.btnTinhNgay_Click);
            // 
            // lblLoiNhuan
            // 
            this.lblLoiNhuan.AutoSize = true;
            this.lblLoiNhuan.Location = new System.Drawing.Point(68, 31);
            this.lblLoiNhuan.Name = "lblLoiNhuan";
            this.lblLoiNhuan.Size = new System.Drawing.Size(0, 13);
            this.lblLoiNhuan.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ngày";
            // 
            // txtNgay
            // 
            this.txtNgay.Location = new System.Drawing.Point(74, 31);
            this.txtNgay.Name = "txtNgay";
            this.txtNgay.Size = new System.Drawing.Size(139, 20);
            this.txtNgay.TabIndex = 0;
            // 
            // btnTinhNam
            // 
            this.btnTinhNam.Location = new System.Drawing.Point(248, 19);
            this.btnTinhNam.Name = "btnTinhNam";
            this.btnTinhNam.Size = new System.Drawing.Size(75, 23);
            this.btnTinhNam.TabIndex = 2;
            this.btnTinhNam.Text = "Tính";
            this.btnTinhNam.UseVisualStyleBackColor = true;
            this.btnTinhNam.Click += new System.EventHandler(this.btnTinhNam_Click);
            // 
            // grbNam
            // 
            this.grbNam.Controls.Add(this.txtTienNam);
            this.grbNam.Controls.Add(this.btnTinhNam);
            this.grbNam.Controls.Add(this.label5);
            this.grbNam.Controls.Add(this.txtNam);
            this.grbNam.Location = new System.Drawing.Point(135, 206);
            this.grbNam.Name = "grbNam";
            this.grbNam.Size = new System.Drawing.Size(477, 57);
            this.grbNam.TabIndex = 10;
            this.grbNam.TabStop = false;
            this.grbNam.Text = "Theo Năm";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Năm";
            // 
            // txtNam
            // 
            this.txtNam.Location = new System.Drawing.Point(74, 19);
            this.txtNam.Name = "txtNam";
            this.txtNam.Size = new System.Drawing.Size(139, 20);
            this.txtNam.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 276);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Thông tin các hóa đơn:";
            // 
            // dgvLoiNhuan
            // 
            this.dgvLoiNhuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoiNhuan.Location = new System.Drawing.Point(12, 299);
            this.dgvLoiNhuan.Name = "dgvLoiNhuan";
            this.dgvLoiNhuan.Size = new System.Drawing.Size(710, 179);
            this.dgvLoiNhuan.TabIndex = 12;
            this.dgvLoiNhuan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLoiNhuan_CellClick);
            // 
            // cmbHinhThuc
            // 
            this.cmbHinhThuc.FormattingEnabled = true;
            this.cmbHinhThuc.Location = new System.Drawing.Point(171, 17);
            this.cmbHinhThuc.Name = "cmbHinhThuc";
            this.cmbHinhThuc.Size = new System.Drawing.Size(159, 21);
            this.cmbHinhThuc.TabIndex = 6;
            this.cmbHinhThuc.SelectedIndexChanged += new System.EventHandler(this.cmbHinhThuc_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Chọn hình thức tính lợi nhuận: ";
            // 
            // QL_TaiChinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(738, 499);
            this.Controls.Add(this.grbThang);
            this.Controls.Add(this.grbNgay);
            this.Controls.Add(this.grbNam);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvLoiNhuan);
            this.Controls.Add(this.cmbHinhThuc);
            this.Controls.Add(this.label1);
            this.Name = "QL_TaiChinh";
            this.Text = "QL_TaiChinh";
            this.Load += new System.EventHandler(this.QL_TaiChinh_Load);
            this.grbThang.ResumeLayout(false);
            this.grbThang.PerformLayout();
            this.grbNgay.ResumeLayout(false);
            this.grbNgay.PerformLayout();
            this.grbNam.ResumeLayout(false);
            this.grbNam.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoiNhuan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTienNam;
        private System.Windows.Forms.TextBox txtTienThang;
        private System.Windows.Forms.GroupBox grbThang;
        private System.Windows.Forms.Button btnTinhThang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtThang;
        private System.Windows.Forms.TextBox txtTienNgay;
        private System.Windows.Forms.GroupBox grbNgay;
        private System.Windows.Forms.Button btnTinhNgay;
        private System.Windows.Forms.Label lblLoiNhuan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNgay;
        private System.Windows.Forms.Button btnTinhNam;
        private System.Windows.Forms.GroupBox grbNam;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvLoiNhuan;
        private System.Windows.Forms.ComboBox cmbHinhThuc;
        private System.Windows.Forms.Label label1;
    }
}