﻿namespace QL_BanHang
{
    partial class QL_DoanhThu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QL_DoanhThu));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvLoiNhuan = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grbThang = new System.Windows.Forms.GroupBox();
            this.txtTienThang = new System.Windows.Forms.TextBox();
            this.btnTinhThang = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtThang = new System.Windows.Forms.TextBox();
            this.cmbHinhThuc = new System.Windows.Forms.ComboBox();
            this.grbNgay = new System.Windows.Forms.GroupBox();
            this.txtTienNgay = new System.Windows.Forms.TextBox();
            this.btnTinhNgay = new System.Windows.Forms.Button();
            this.lblLoiNhuan = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNgay = new System.Windows.Forms.TextBox();
            this.grbNam = new System.Windows.Forms.GroupBox();
            this.txtTienNam = new System.Windows.Forms.TextBox();
            this.btnTinhNam = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNam = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvDSBan = new System.Windows.Forms.DataGridView();
            this.MaHD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaHH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenNCC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoiNhuan)).BeginInit();
            this.panel1.SuspendLayout();
            this.grbThang.SuspendLayout();
            this.grbNgay.SuspendLayout();
            this.grbNam.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSBan)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1513, 836);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(672, 828);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvLoiNhuan);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(4, 335);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(664, 489);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Doanh thu";
            // 
            // dgvLoiNhuan
            // 
            this.dgvLoiNhuan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLoiNhuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoiNhuan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvLoiNhuan.Location = new System.Drawing.Point(4, 19);
            this.dgvLoiNhuan.Margin = new System.Windows.Forms.Padding(4);
            this.dgvLoiNhuan.Name = "dgvLoiNhuan";
            this.dgvLoiNhuan.RowHeadersWidth = 51;
            this.dgvLoiNhuan.Size = new System.Drawing.Size(656, 466);
            this.dgvLoiNhuan.TabIndex = 26;
            this.dgvLoiNhuan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLoiNhuan_CellClick_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.grbThang);
            this.panel1.Controls.Add(this.cmbHinhThuc);
            this.panel1.Controls.Add(this.grbNgay);
            this.panel1.Controls.Add(this.grbNam);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(664, 323);
            this.panel1.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(103, 284);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(429, 17);
            this.label7.TabIndex = 32;
            this.label7.Text = "hiện thị lợi nhuận và các hóa đơn hàng hóa được lập ngày hôm đó.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(99, 256);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(494, 17);
            this.label6.TabIndex = 31;
            this.label6.Text = "Click vào cột ngày lập trong bảng doanh thu để chọn  ngày , tháng , năm cần";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 257);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 30;
            this.label2.Text = "Lưu ý: ";
            // 
            // grbThang
            // 
            this.grbThang.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grbThang.Controls.Add(this.txtTienThang);
            this.grbThang.Controls.Add(this.btnTinhThang);
            this.grbThang.Controls.Add(this.label4);
            this.grbThang.Controls.Add(this.txtThang);
            this.grbThang.Location = new System.Drawing.Point(16, 111);
            this.grbThang.Margin = new System.Windows.Forms.Padding(4);
            this.grbThang.Name = "grbThang";
            this.grbThang.Padding = new System.Windows.Forms.Padding(4);
            this.grbThang.Size = new System.Drawing.Size(636, 55);
            this.grbThang.TabIndex = 28;
            this.grbThang.TabStop = false;
            this.grbThang.Text = "Theo Tháng";
            // 
            // txtTienThang
            // 
            this.txtTienThang.Location = new System.Drawing.Point(480, 21);
            this.txtTienThang.Margin = new System.Windows.Forms.Padding(4);
            this.txtTienThang.Name = "txtTienThang";
            this.txtTienThang.Size = new System.Drawing.Size(132, 22);
            this.txtTienThang.TabIndex = 3;
            // 
            // btnTinhThang
            // 
            this.btnTinhThang.Image = ((System.Drawing.Image)(resources.GetObject("btnTinhThang.Image")));
            this.btnTinhThang.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTinhThang.Location = new System.Drawing.Point(331, 12);
            this.btnTinhThang.Margin = new System.Windows.Forms.Padding(4);
            this.btnTinhThang.Name = "btnTinhThang";
            this.btnTinhThang.Size = new System.Drawing.Size(119, 36);
            this.btnTinhThang.TabIndex = 2;
            this.btnTinhThang.Text = "Check";
            this.btnTinhThang.UseVisualStyleBackColor = true;
            this.btnTinhThang.Click += new System.EventHandler(this.btnTinhThang_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 25);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Tháng";
            // 
            // txtThang
            // 
            this.txtThang.Location = new System.Drawing.Point(99, 21);
            this.txtThang.Margin = new System.Windows.Forms.Padding(4);
            this.txtThang.Name = "txtThang";
            this.txtThang.Size = new System.Drawing.Size(184, 22);
            this.txtThang.TabIndex = 1;
            // 
            // cmbHinhThuc
            // 
            this.cmbHinhThuc.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cmbHinhThuc.FormattingEnabled = true;
            this.cmbHinhThuc.Location = new System.Drawing.Point(231, 12);
            this.cmbHinhThuc.Margin = new System.Windows.Forms.Padding(4);
            this.cmbHinhThuc.Name = "cmbHinhThuc";
            this.cmbHinhThuc.Size = new System.Drawing.Size(211, 24);
            this.cmbHinhThuc.TabIndex = 25;
            this.cmbHinhThuc.SelectedIndexChanged += new System.EventHandler(this.cmbHinhThuc_SelectedIndexChanged);
            // 
            // grbNgay
            // 
            this.grbNgay.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grbNgay.Controls.Add(this.txtTienNgay);
            this.grbNgay.Controls.Add(this.btnTinhNgay);
            this.grbNgay.Controls.Add(this.lblLoiNhuan);
            this.grbNgay.Controls.Add(this.label3);
            this.grbNgay.Controls.Add(this.txtNgay);
            this.grbNgay.Location = new System.Drawing.Point(16, 46);
            this.grbNgay.Margin = new System.Windows.Forms.Padding(4);
            this.grbNgay.Name = "grbNgay";
            this.grbNgay.Padding = new System.Windows.Forms.Padding(4);
            this.grbNgay.Size = new System.Drawing.Size(644, 58);
            this.grbNgay.TabIndex = 27;
            this.grbNgay.TabStop = false;
            this.grbNgay.Text = "Theo Ngày";
            // 
            // txtTienNgay
            // 
            this.txtTienNgay.Location = new System.Drawing.Point(480, 21);
            this.txtTienNgay.Margin = new System.Windows.Forms.Padding(4);
            this.txtTienNgay.Name = "txtTienNgay";
            this.txtTienNgay.Size = new System.Drawing.Size(132, 22);
            this.txtTienNgay.TabIndex = 3;
            // 
            // btnTinhNgay
            // 
            this.btnTinhNgay.Image = ((System.Drawing.Image)(resources.GetObject("btnTinhNgay.Image")));
            this.btnTinhNgay.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTinhNgay.Location = new System.Drawing.Point(331, 15);
            this.btnTinhNgay.Margin = new System.Windows.Forms.Padding(4);
            this.btnTinhNgay.Name = "btnTinhNgay";
            this.btnTinhNgay.Size = new System.Drawing.Size(119, 35);
            this.btnTinhNgay.TabIndex = 2;
            this.btnTinhNgay.Text = "Check";
            this.btnTinhNgay.UseVisualStyleBackColor = true;
            this.btnTinhNgay.Click += new System.EventHandler(this.btnTinhNgay_Click);
            // 
            // lblLoiNhuan
            // 
            this.lblLoiNhuan.AutoSize = true;
            this.lblLoiNhuan.Location = new System.Drawing.Point(91, 21);
            this.lblLoiNhuan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLoiNhuan.Name = "lblLoiNhuan";
            this.lblLoiNhuan.Size = new System.Drawing.Size(0, 17);
            this.lblLoiNhuan.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 25);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ngày";
            // 
            // txtNgay
            // 
            this.txtNgay.Location = new System.Drawing.Point(99, 21);
            this.txtNgay.Margin = new System.Windows.Forms.Padding(4);
            this.txtNgay.Name = "txtNgay";
            this.txtNgay.Size = new System.Drawing.Size(184, 22);
            this.txtNgay.TabIndex = 0;
            // 
            // grbNam
            // 
            this.grbNam.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grbNam.Controls.Add(this.txtTienNam);
            this.grbNam.Controls.Add(this.btnTinhNam);
            this.grbNam.Controls.Add(this.label5);
            this.grbNam.Controls.Add(this.txtNam);
            this.grbNam.Location = new System.Drawing.Point(16, 174);
            this.grbNam.Margin = new System.Windows.Forms.Padding(4);
            this.grbNam.Name = "grbNam";
            this.grbNam.Padding = new System.Windows.Forms.Padding(4);
            this.grbNam.Size = new System.Drawing.Size(636, 54);
            this.grbNam.TabIndex = 29;
            this.grbNam.TabStop = false;
            this.grbNam.Text = "Theo Năm";
            // 
            // txtTienNam
            // 
            this.txtTienNam.Location = new System.Drawing.Point(480, 17);
            this.txtTienNam.Margin = new System.Windows.Forms.Padding(4);
            this.txtTienNam.Name = "txtTienNam";
            this.txtTienNam.Size = new System.Drawing.Size(132, 22);
            this.txtTienNam.TabIndex = 3;
            // 
            // btnTinhNam
            // 
            this.btnTinhNam.Image = ((System.Drawing.Image)(resources.GetObject("btnTinhNam.Image")));
            this.btnTinhNam.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTinhNam.Location = new System.Drawing.Point(331, 11);
            this.btnTinhNam.Margin = new System.Windows.Forms.Padding(4);
            this.btnTinhNam.Name = "btnTinhNam";
            this.btnTinhNam.Size = new System.Drawing.Size(119, 37);
            this.btnTinhNam.TabIndex = 2;
            this.btnTinhNam.Text = "Check";
            this.btnTinhNam.UseVisualStyleBackColor = true;
            this.btnTinhNam.Click += new System.EventHandler(this.btnTinhNam_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 21);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Năm";
            // 
            // txtNam
            // 
            this.txtNam.Location = new System.Drawing.Point(99, 17);
            this.txtNam.Margin = new System.Windows.Forms.Padding(4);
            this.txtNam.Name = "txtNam";
            this.txtNam.Size = new System.Drawing.Size(184, 22);
            this.txtNam.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 17);
            this.label1.TabIndex = 26;
            this.label1.Text = "Chọn hình thức tính lợi nhuận: ";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.groupBox2, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(684, 4);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(825, 828);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvDSBan);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(4, 4);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(817, 820);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Danh sách sản phẩm bán";
            // 
            // dgvDSBan
            // 
            this.dgvDSBan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDSBan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSBan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHD,
            this.TenKH,
            this.MaHH,
            this.TenHang,
            this.TenNCC,
            this.DonGia,
            this.SoLuong,
            this.MaNV,
            this.TenNV,
            this.NgayLap});
            this.dgvDSBan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDSBan.Location = new System.Drawing.Point(4, 19);
            this.dgvDSBan.Margin = new System.Windows.Forms.Padding(4);
            this.dgvDSBan.Name = "dgvDSBan";
            this.dgvDSBan.RowHeadersWidth = 51;
            this.dgvDSBan.Size = new System.Drawing.Size(809, 797);
            this.dgvDSBan.TabIndex = 0;
            // 
            // MaHD
            // 
            this.MaHD.DataPropertyName = "MaHDCT";
            this.MaHD.HeaderText = "Mã HD";
            this.MaHD.MinimumWidth = 6;
            this.MaHD.Name = "MaHD";
            // 
            // TenKH
            // 
            this.TenKH.DataPropertyName = "TenKH";
            this.TenKH.HeaderText = "Tên KH";
            this.TenKH.MinimumWidth = 6;
            this.TenKH.Name = "TenKH";
            // 
            // MaHH
            // 
            this.MaHH.DataPropertyName = "MaHH";
            this.MaHH.HeaderText = "Mã HH";
            this.MaHH.MinimumWidth = 6;
            this.MaHH.Name = "MaHH";
            // 
            // TenHang
            // 
            this.TenHang.DataPropertyName = "TenHang";
            this.TenHang.HeaderText = "Tên Hàng";
            this.TenHang.MinimumWidth = 6;
            this.TenHang.Name = "TenHang";
            // 
            // TenNCC
            // 
            this.TenNCC.DataPropertyName = "TenNCC";
            this.TenNCC.HeaderText = "Tên NCC";
            this.TenNCC.MinimumWidth = 6;
            this.TenNCC.Name = "TenNCC";
            // 
            // DonGia
            // 
            this.DonGia.DataPropertyName = "DonGia";
            this.DonGia.HeaderText = "Đơn Giá";
            this.DonGia.MinimumWidth = 6;
            this.DonGia.Name = "DonGia";
            // 
            // SoLuong
            // 
            this.SoLuong.DataPropertyName = "SoLuong";
            this.SoLuong.HeaderText = "Số Lượng";
            this.SoLuong.MinimumWidth = 6;
            this.SoLuong.Name = "SoLuong";
            // 
            // MaNV
            // 
            this.MaNV.DataPropertyName = "MaNV";
            this.MaNV.HeaderText = "Mã NV";
            this.MaNV.MinimumWidth = 6;
            this.MaNV.Name = "MaNV";
            // 
            // TenNV
            // 
            this.TenNV.DataPropertyName = "TenNV";
            this.TenNV.HeaderText = "Tên NV";
            this.TenNV.MinimumWidth = 6;
            this.TenNV.Name = "TenNV";
            // 
            // NgayLap
            // 
            this.NgayLap.DataPropertyName = "NgayLap";
            this.NgayLap.HeaderText = "Ngày Lập";
            this.NgayLap.MinimumWidth = 6;
            this.NgayLap.Name = "NgayLap";
            // 
            // QL_DoanhThu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1513, 836);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1529, 873);
            this.Name = "QL_DoanhThu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doanh thu";
            this.Load += new System.EventHandler(this.QL_DoanhThu_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoiNhuan)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grbThang.ResumeLayout(false);
            this.grbThang.PerformLayout();
            this.grbNgay.ResumeLayout(false);
            this.grbNgay.PerformLayout();
            this.grbNam.ResumeLayout(false);
            this.grbNam.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSBan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvLoiNhuan;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox grbThang;
        private System.Windows.Forms.TextBox txtTienThang;
        private System.Windows.Forms.Button btnTinhThang;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txtThang;
        private System.Windows.Forms.ComboBox cmbHinhThuc;
        private System.Windows.Forms.GroupBox grbNgay;
        private System.Windows.Forms.TextBox txtTienNgay;
        private System.Windows.Forms.Button btnTinhNgay;
        private System.Windows.Forms.Label lblLoiNhuan;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtNgay;
        private System.Windows.Forms.GroupBox grbNam;
        private System.Windows.Forms.TextBox txtTienNam;
        private System.Windows.Forms.Button btnTinhNam;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txtNam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvDSBan;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHD;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenNCC;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;
    }
}