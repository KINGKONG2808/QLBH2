﻿namespace QL_BanHang
{
    partial class TrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangChu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolTripQuanLy = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khoHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loạiHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lịchSửGiáToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTripKhachHang = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTripNhaCC = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTripNhanVien = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTrìnhĐộToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTripTaiChinh = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinChungToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.nhómPhátTriểnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vũVănHùng2017601398ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phạmVănYên2017600216ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nguyễnKhắcHiếu2017603774ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vũViệtTùng2017601480ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolTripQuanLy,
            this.toolTripKhachHang,
            this.toolTripNhaCC,
            this.toolTripNhanVien,
            this.toolTripTaiChinh,
            this.thôngTinChungToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(943, 28);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolTripQuanLy
            // 
            this.toolTripQuanLy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýHóaĐơnToolStripMenuItem,
            this.nhậpHàngToolStripMenuItem,
            this.khoHàngToolStripMenuItem,
            this.loạiHàngToolStripMenuItem,
            this.lịchSửGiáToolStripMenuItem});
            this.toolTripQuanLy.Name = "toolTripQuanLy";
            this.toolTripQuanLy.Size = new System.Drawing.Size(73, 24);
            this.toolTripQuanLy.Text = "Quản lý";
            this.toolTripQuanLy.Click += new System.EventHandler(this.toolTripQuanLy_Click);
            // 
            // quảnLýHóaĐơnToolStripMenuItem
            // 
            this.quảnLýHóaĐơnToolStripMenuItem.Name = "quảnLýHóaĐơnToolStripMenuItem";
            this.quảnLýHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.quảnLýHóaĐơnToolStripMenuItem.Text = "Đơn hàng";
            this.quảnLýHóaĐơnToolStripMenuItem.Click += new System.EventHandler(this.quảnLýHóaĐơnToolStripMenuItem_Click);
            // 
            // nhậpHàngToolStripMenuItem
            // 
            this.nhậpHàngToolStripMenuItem.Name = "nhậpHàngToolStripMenuItem";
            this.nhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.nhậpHàngToolStripMenuItem.Text = "Nhập hàng";
            this.nhậpHàngToolStripMenuItem.Click += new System.EventHandler(this.nhậpHàngToolStripMenuItem_Click);
            // 
            // khoHàngToolStripMenuItem
            // 
            this.khoHàngToolStripMenuItem.Name = "khoHàngToolStripMenuItem";
            this.khoHàngToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.khoHàngToolStripMenuItem.Text = "Kho hàng";
            this.khoHàngToolStripMenuItem.Click += new System.EventHandler(this.khoHàngToolStripMenuItem_Click);
            // 
            // loạiHàngToolStripMenuItem
            // 
            this.loạiHàngToolStripMenuItem.Name = "loạiHàngToolStripMenuItem";
            this.loạiHàngToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.loạiHàngToolStripMenuItem.Text = "Loại hàng";
            this.loạiHàngToolStripMenuItem.Click += new System.EventHandler(this.loạiHàngToolStripMenuItem_Click);
            // 
            // lịchSửGiáToolStripMenuItem
            // 
            this.lịchSửGiáToolStripMenuItem.Name = "lịchSửGiáToolStripMenuItem";
            this.lịchSửGiáToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.lịchSửGiáToolStripMenuItem.Text = "Lịch sử giá";
            this.lịchSửGiáToolStripMenuItem.Click += new System.EventHandler(this.lịchSửGiáToolStripMenuItem_Click);
            // 
            // toolTripKhachHang
            // 
            this.toolTripKhachHang.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.toolTripKhachHang.Name = "toolTripKhachHang";
            this.toolTripKhachHang.Size = new System.Drawing.Size(100, 24);
            this.toolTripKhachHang.Text = "Khách hàng";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(234, 26);
            this.toolStripMenuItem1.Text = "Thông tin khách hàng";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolTripNhaCC
            // 
            this.toolTripNhaCC.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2});
            this.toolTripNhaCC.Name = "toolTripNhaCC";
            this.toolTripNhaCC.Size = new System.Drawing.Size(114, 24);
            this.toolTripNhaCC.Text = "Nhà cung cấp";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(247, 26);
            this.toolStripMenuItem2.Text = "Thông tin nhà cung cấp";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolTripNhanVien
            // 
            this.toolTripNhanVien.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.thôngTinTrìnhĐộToolStripMenuItem});
            this.toolTripNhanVien.Name = "toolTripNhanVien";
            this.toolTripNhanVien.Size = new System.Drawing.Size(89, 24);
            this.toolTripNhanVien.Text = "Nhân viên";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(224, 26);
            this.toolStripMenuItem3.Text = "Thông tin nhân viên";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // thôngTinTrìnhĐộToolStripMenuItem
            // 
            this.thôngTinTrìnhĐộToolStripMenuItem.Name = "thôngTinTrìnhĐộToolStripMenuItem";
            this.thôngTinTrìnhĐộToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.thôngTinTrìnhĐộToolStripMenuItem.Text = "Thông tin trình độ";
            this.thôngTinTrìnhĐộToolStripMenuItem.Click += new System.EventHandler(this.thôngTinTrìnhĐộToolStripMenuItem_Click);
            // 
            // toolTripTaiChinh
            // 
            this.toolTripTaiChinh.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.toolStripMenuItem5});
            this.toolTripTaiChinh.Name = "toolTripTaiChinh";
            this.toolTripTaiChinh.Size = new System.Drawing.Size(80, 24);
            this.toolTripTaiChinh.Text = "Tài chính";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(236, 26);
            this.toolStripMenuItem4.Text = "Doanh thu";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click_1);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(236, 26);
            this.toolStripMenuItem5.Text = "Bảng lương nhân viên";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // thôngTinChungToolStripMenuItem
            // 
            this.thôngTinChungToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator2,
            this.nhómPhátTriểnToolStripMenuItem,
            this.toolStripSeparator1,
            this.đăngXuấtToolStripMenuItem,
            this.thoátToolStripMenuItem1});
            this.thôngTinChungToolStripMenuItem.Name = "thôngTinChungToolStripMenuItem";
            this.thôngTinChungToolStripMenuItem.Size = new System.Drawing.Size(130, 24);
            this.thôngTinChungToolStripMenuItem.Text = "Thông tin chung";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem1
            // 
            this.thoátToolStripMenuItem1.Name = "thoátToolStripMenuItem1";
            this.thoátToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.thoátToolStripMenuItem1.Text = "Thoát";
            this.thoátToolStripMenuItem1.Click += new System.EventHandler(this.thoátToolStripMenuItem1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-61, 143);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1035, 395);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(52, 73);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(780, 39);
            this.label2.TabIndex = 9;
            this.label2.Text = "Giải pháp quản lý tối ưu nhất cho các quán cafe";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(37, 576);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(160, 95);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(239, 576);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(160, 95);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(464, 576);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(160, 95);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(689, 576);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(160, 95);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // nhómPhátTriểnToolStripMenuItem
            // 
            this.nhómPhátTriểnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vũVănHùng2017601398ToolStripMenuItem,
            this.phạmVănYên2017600216ToolStripMenuItem,
            this.nguyễnKhắcHiếu2017603774ToolStripMenuItem,
            this.vũViệtTùng2017601480ToolStripMenuItem});
            this.nhómPhátTriểnToolStripMenuItem.Name = "nhómPhátTriểnToolStripMenuItem";
            this.nhómPhátTriểnToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.nhómPhátTriểnToolStripMenuItem.Text = "Nhóm phát triển";
            // 
            // vũVănHùng2017601398ToolStripMenuItem
            // 
            this.vũVănHùng2017601398ToolStripMenuItem.Name = "vũVănHùng2017601398ToolStripMenuItem";
            this.vũVănHùng2017601398ToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.vũVănHùng2017601398ToolStripMenuItem.Text = "Vũ Văn Hùng - 2017601398";
            // 
            // phạmVănYên2017600216ToolStripMenuItem
            // 
            this.phạmVănYên2017600216ToolStripMenuItem.Name = "phạmVănYên2017600216ToolStripMenuItem";
            this.phạmVănYên2017600216ToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.phạmVănYên2017600216ToolStripMenuItem.Text = "Phạm Văn Yên - 2017600216";
            // 
            // nguyễnKhắcHiếu2017603774ToolStripMenuItem
            // 
            this.nguyễnKhắcHiếu2017603774ToolStripMenuItem.Name = "nguyễnKhắcHiếu2017603774ToolStripMenuItem";
            this.nguyễnKhắcHiếu2017603774ToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.nguyễnKhắcHiếu2017603774ToolStripMenuItem.Text = "Nguyễn Khắc Hiếu - 2017603774";
            // 
            // vũViệtTùng2017601480ToolStripMenuItem
            // 
            this.vũViệtTùng2017601480ToolStripMenuItem.Name = "vũViệtTùng2017601480ToolStripMenuItem";
            this.vũViệtTùng2017601480ToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.vũViệtTùng2017601480ToolStripMenuItem.Text = "Vũ Việt Tùng - 2017601480";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(221, 6);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(221, 6);
            // 
            // TrangChu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(943, 686);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "TrangChu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang chủ";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TrangChu_FormClosed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhậpHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khoHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        public System.Windows.Forms.ToolStripMenuItem toolTripQuanLy;
        public System.Windows.Forms.ToolStripMenuItem toolTripKhachHang;
        public System.Windows.Forms.ToolStripMenuItem toolTripNhaCC;
        public System.Windows.Forms.ToolStripMenuItem toolTripTaiChinh;
        public System.Windows.Forms.ToolStripMenuItem toolTripNhanVien;
        private System.Windows.Forms.ToolStripMenuItem thôngTinChungToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem loạiHàngToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ToolStripMenuItem lịchSửGiáToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTrìnhĐộToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem nhómPhátTriểnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vũVănHùng2017601398ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phạmVănYên2017600216ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nguyễnKhắcHiếu2017603774ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vũViệtTùng2017601480ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}